package qzhenghao.cn.yumunote.bean;

import java.util.List;

/**
 * @author suiyue
 * @ClassName BackUPItem
 * @Description TODO
 * @date 2019/10/30 19:37
 */
public class BackUPItem {

    List<FolderItemBean> folderItemBeans;
    List<NoteItemBean> noteItemBeans;


}
